package com.nik;

public class Main {
    public static void main(String[] args) throws InterruptedException {
	Session mySession = new Session();
	mySession.app();
    }
}
